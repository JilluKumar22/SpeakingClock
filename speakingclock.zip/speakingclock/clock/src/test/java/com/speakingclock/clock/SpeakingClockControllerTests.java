package com.speakingclock.clock;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
 
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.speakingclock.controller.SpeakingClockController;
import com.speakingclock.service.SpeakingClockService;
import com.speakingclock.util.ValidationUtil;

@RunWith(MockitoJUnitRunner.class)
public class SpeakingClockControllerTests {

	@InjectMocks
	SpeakingClockController speakingClockController;
	
	
	@Mock
	SpeakingClockService clockService;
	
	@Mock
	ValidationUtil validationUtil;
	
	
	
	@Test
	public void testValidTimeForMidnight() {
		
		Mockito.when(validationUtil.isValidTime(ArgumentMatchers.anyString())).thenReturn(true);
		Mockito.when(clockService.speakTime(ArgumentMatchers.anyInt(),ArgumentMatchers.anyInt())).thenReturn("It's Midnight");
		ResponseEntity<String> response = speakingClockController.getMessage("\"24:00\"");

		assertNotNull(clockService);
		assertNotNull(validationUtil);
		//assertEquals("200 OK", response.getStatusCode());
		assertEquals("It's Midnight", response.getBody());
	}
	
	@Test
	public void testValidTimeForOther() {
		
		Mockito.when(validationUtil.isValidTime(ArgumentMatchers.anyString())).thenReturn(true);
		Mockito.when(clockService.speakTime(ArgumentMatchers.anyInt(),ArgumentMatchers.anyInt())).thenReturn("It's ten o' two");
		ResponseEntity<String> response = speakingClockController.getMessage("\"22:02\"");
        assertNotNull(clockService);
		assertNotNull(clockService);
		assertNotNull(validationUtil);
		//assertEquals("200 OK", response.getStatusCode());
		assertEquals("It's ten o' two", response.getBody());
	}
	
	@Test
	public void InValidTime() {
		
		Mockito.when(validationUtil.isValidTime(ArgumentMatchers.anyString())).thenReturn(true);
		//Mockito.when(clockService.speakTime(ArgumentMatchers.anyInt(),ArgumentMatchers.anyInt())).thenReturn("It's ten o' two");
		// pass some invalid time
		ResponseEntity<String> response = speakingClockController.getMessage("\"2a2:02\"");
		assertNotNull(clockService);
		assertNotNull(validationUtil);
		assertNotEquals("It's ten o' two", response.getBody());
	}

}