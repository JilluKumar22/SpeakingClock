package com.speakingclock.exception;

public class InValidTimeFormatException  extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 4805653911206360164L;


	public InValidTimeFormatException(String msg){

		super(msg);
	}
}