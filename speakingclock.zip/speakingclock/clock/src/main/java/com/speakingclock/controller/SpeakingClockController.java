package com.speakingclock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.speakingclock.exception.InValidTimeFormatException;
import com.speakingclock.service.SpeakingClockService;
import com.speakingclock.util.ValidationUtil;

// GET :  http://localhost:8080/clock/speakTime/"21:00"


@RestController
@RequestMapping("/clock")
public class SpeakingClockController {


@Autowired
private SpeakingClockService clockService;

@Autowired
ValidationUtil validationUtil;

@RequestMapping(value="/speakTime/{time}", method = RequestMethod.GET, produces = { "application/json" })

public ResponseEntity<String> getMessage(@PathVariable String time) {

String inputTime = time;
 
try {
if (validationUtil.isValidTime(inputTime)) {
String hrMin [] = time.replace("\"","").split(":");
int hr = Integer.parseInt(hrMin[0].toString());
int min = Integer.parseInt(hrMin[1].toString());
String response = clockService.speakTime(hr, min);
return new ResponseEntity<>(response , HttpStatus.OK);
}
 
}catch (InValidTimeFormatException e) {
  e.printStackTrace();
throw new InValidTimeFormatException("Invalid Time format Given");

}
catch (Exception e) {
  e.printStackTrace();
}
return new ResponseEntity<>("Invalid Time Entered" , HttpStatus.BAD_REQUEST);
}


// eg : GET:  http://localhost:8080/clock/speakTime/"21:00"

}