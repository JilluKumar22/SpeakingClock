package com.speakingclock.util;

import org.springframework.stereotype.Component;

import com.speakingclock.exception.InValidTimeFormatException;

@Component
public class ValidationUtil {


	public boolean isValidTime(String time) {

		boolean flag = false;
		String hrMin [] = time.replace("\"","").split(":");

		if(hrMin[0].length() <= 2)
			if (hrMin[1].length() <= 2 ) {
				flag = hrMin[0].chars().allMatch(c -> c >= 48 && c <= 57);
			}
		if(!flag)
			throw new InValidTimeFormatException("Invalid Time");
		return flag;
	}
}