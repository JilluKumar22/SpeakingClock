package com.speakingclock.service;

import org.springframework.stereotype.Component;

@Component
public class SpeakingClockServiceImpl  implements SpeakingClockService  {

	private int hours=0;
	private int minutes=0;
	private String result ="";

	private static final String[] TENS = {"o' ", "", "twenty ", "thirty ", "forty ", "fifty "};

	private static final String[] ONES = {
			"twelve ", "one ", "two ", "three ", "four ", "five ",
			"six ", "seven ", "eight ", "nine ", "ten ", "eleven ",
			"twelve ", "thirteen ", "fourteen ", "fifteen ",
			"sixteen ", "seventeen ", "eighteen ", "nineteen "
	};


	@Override
	public String speakTime(int hr, int min) {

		this.hours = hr;
		this.minutes = min;

		StringBuilder result = new StringBuilder();

		if (this.minutes == 0) {
			if (this.hours == 12) {
				return result.append("It's Midday").toString();
			}
			if (this.hours == 24) {
				return result.append("It's Midnight").toString();
			}
			if (this.hours != 12 && this.hours != 24)
				return result.append("It's ").append(ONES[hours % 12]).toString();
		}
		else if (minutes % 10 == 0) {
			result.append("It's ").append(ONES[hours % 12]).append(TENS[minutes / 10]);
		} else if (minutes < 10 || minutes > 20) {
			result.append("It's ").append(ONES[hours % 12]).append(TENS[minutes / 10]).append(ONES[minutes % 10]);
		} else {
			result.append("It's ").append(ONES[hours % 12]).append(ONES[minutes]);
		}
		return result.toString();

	}
}
