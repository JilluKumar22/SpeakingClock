package com.speakingclock.service;

public interface SpeakingClockService {


	public String speakTime(int hr, int min);
}